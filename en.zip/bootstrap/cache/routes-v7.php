<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4CMwSDrR24J4fJ5v',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jT5Pe9qLNjql89V8',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::np4K0SyFIjVo8tVB',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/en/Index' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'FrontEnd.Index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/en/Blank' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'FrontEnd.blank',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Administrator/Signin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::p8z3eMAQZAkIU6Zm',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Administrator/Logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Administrator/Signup' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'register',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3VDWelznnXTz2Fh8',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/password/reset' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.request',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'password.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/password/email' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.email',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/password/confirm' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.confirm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CdaeyFjrFer75YZh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/home' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'home',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Administrator/SuperUser/Dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'supuser.dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Administrator/SuperUser/Dashboard/Profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'supuser.profile.dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Administrator/SuperUser/Dashboard/Profile/Update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'supuser.profileupdate.dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Administrator/SuperUser/Dashboard/Profile/Update/Pass' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'supuser.profileupdate.pass.dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Administrator/SuperUser/Dashboard/Users' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'supuser.listuser',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Administrator/SuperUser/Dashboard/Users/Team/List' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'supuser.users.team',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Administrator/SuperUser/Dashboard/Catagory/SuperCatagory' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'supuser.cata.super',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Administrator/SuperUser/Dashboard/Catagory/SuperCatagory/Insert' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'supuser.cata.super.insert',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Administrator/SuperUser/BlankPage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'supuser.blank',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Administrator/Blogger/Dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'blogusr.dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Administrator/Blogger/Dashboard/Users' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'blogusr.users',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Administrator/Blogger/Dashboard/Profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'blogusr.profile.dash',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Administrator/Blogger/Dashboard/Profile/Update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'blogusr.profile.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Administrator/Blogger/Dashboard/Profile/Update/Pass' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'blogusr.profile.update.pass',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Administrator/Blogger/Dashboard/Users/Team' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'blogusr.users.allteam',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Administrator/Blogger/Dashboard/Users/Team/New' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'blogusr.users.allteam.newteam',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Administrator/Blogger/Dashboard/Users/Team/New/TeamInsert' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'blogusr.users.allteam.newteam.insert',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/User/Verify' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'email.verify',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/User/view' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'basUser.view',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/User/Dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'basUser.dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/CybSamDevelopment/Optimize' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'cybsam.dev.optimize',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/password/reset/([^/]++)(*:31)|/Administrator/Blogger/Dashboard/Users/Team/List/(?|([^/]++)(*:98)|AddUser/([^/]++)(*:121)))/?$}sDu',
    ),
    3 => 
    array (
      31 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.reset',
          ),
          1 => 
          array (
            0 => 'token',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      98 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'blogusr.users.allteam.users',
          ),
          1 => 
          array (
            0 => 'nameteam',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      121 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'blogusr.users.allteam.users.add',
          ),
          1 => 
          array (
            0 => 'name_user',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::4CMwSDrR24J4fJ5v' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'generated::4CMwSDrR24J4fJ5v',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jT5Pe9qLNjql89V8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:295:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:77:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000004675082e0000000031d669e6";}";s:4:"hash";s:44:"cbS7VuoGeUSYykigyFlt3wc3ACmZrMu0uiaVCoJdLNo=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::jT5Pe9qLNjql89V8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::np4K0SyFIjVo8tVB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:282:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:64:"function () {
    return \\redirect()->route(\'FrontEnd.Index\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000004675082c0000000031d669e6";}";s:4:"hash";s:44:"gz6pHf19OOHt0SJQfUjM5Lnnzm1IYzKUU6NO3PjACZk=";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::np4K0SyFIjVo8tVB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'FrontEnd.Index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'en/Index',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\FrontEnd\\IndexController@Index',
        'controller' => 'App\\Http\\Controllers\\FrontEnd\\IndexController@Index',
        'namespace' => NULL,
        'prefix' => '/en',
        'where' => 
        array (
        ),
        'as' => 'FrontEnd.Index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'FrontEnd.blank' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'en/Blank',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\FrontEnd\\IndexController@blank',
        'controller' => 'App\\Http\\Controllers\\FrontEnd\\IndexController@blank',
        'namespace' => NULL,
        'prefix' => '/en',
        'where' => 
        array (
        ),
        'as' => 'FrontEnd.blank',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Administrator/Signin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          'middleware' => 'PreBackHistory',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@showLoginForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@showLoginForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::p8z3eMAQZAkIU6Zm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Administrator/Signin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          'middleware' => 'PreBackHistory',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@login',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@login',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::p8z3eMAQZAkIU6Zm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Administrator/Logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          'middleware' => 'PreBackHistory',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@logout',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@logout',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'register' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Administrator/Signup',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          'middleware' => 'PreBackHistory',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\RegisterController@showRegistrationForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\RegisterController@showRegistrationForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'register',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3VDWelznnXTz2Fh8' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Administrator/Signup',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          'middleware' => 'PreBackHistory',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\RegisterController@register',
        'controller' => 'App\\Http\\Controllers\\Auth\\RegisterController@register',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::3VDWelznnXTz2Fh8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.request' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'password/reset',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          'middleware' => 'PreBackHistory',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@showLinkRequestForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@showLinkRequestForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.request',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.email' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'password/email',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          'middleware' => 'PreBackHistory',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@sendResetLinkEmail',
        'controller' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@sendResetLinkEmail',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.email',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.reset' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'password/reset/{token}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          'middleware' => 'PreBackHistory',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@showResetForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@showResetForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.reset',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'password/reset',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          'middleware' => 'PreBackHistory',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@reset',
        'controller' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@reset',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.confirm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'password/confirm',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          'middleware' => 'PreBackHistory',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@showConfirmForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@showConfirmForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.confirm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CdaeyFjrFer75YZh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'password/confirm',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          'middleware' => 'PreBackHistory',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@confirm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@confirm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::CdaeyFjrFer75YZh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'home' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'home',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\HomeController@index',
        'controller' => 'App\\Http\\Controllers\\HomeController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'home',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'supuser.dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Administrator/SuperUser/Dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'supUser',
          3 => 'PreBackHistory',
          4 => 'is_user_verify_email',
        ),
        'uses' => 'App\\Http\\Controllers\\SupUser\\SupUserDashController@index',
        'controller' => 'App\\Http\\Controllers\\SupUser\\SupUserDashController@index',
        'namespace' => NULL,
        'prefix' => '/Administrator/SuperUser',
        'where' => 
        array (
        ),
        'as' => 'supuser.dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'supuser.profile.dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Administrator/SuperUser/Dashboard/Profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'supUser',
          3 => 'PreBackHistory',
          4 => 'is_user_verify_email',
        ),
        'uses' => 'App\\Http\\Controllers\\SupUser\\SupUserDashController@UserProfile',
        'controller' => 'App\\Http\\Controllers\\SupUser\\SupUserDashController@UserProfile',
        'namespace' => NULL,
        'prefix' => '/Administrator/SuperUser',
        'where' => 
        array (
        ),
        'as' => 'supuser.profile.dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'supuser.profileupdate.dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Administrator/SuperUser/Dashboard/Profile/Update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'supUser',
          3 => 'PreBackHistory',
          4 => 'is_user_verify_email',
        ),
        'uses' => 'App\\Http\\Controllers\\SupUser\\SupUserDashController@UserProfileUpdate',
        'controller' => 'App\\Http\\Controllers\\SupUser\\SupUserDashController@UserProfileUpdate',
        'namespace' => NULL,
        'prefix' => '/Administrator/SuperUser',
        'where' => 
        array (
        ),
        'as' => 'supuser.profileupdate.dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'supuser.profileupdate.pass.dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Administrator/SuperUser/Dashboard/Profile/Update/Pass',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'supUser',
          3 => 'PreBackHistory',
          4 => 'is_user_verify_email',
        ),
        'uses' => 'App\\Http\\Controllers\\SupUser\\SupUserDashController@UserProfileUpdatePass',
        'controller' => 'App\\Http\\Controllers\\SupUser\\SupUserDashController@UserProfileUpdatePass',
        'namespace' => NULL,
        'prefix' => '/Administrator/SuperUser',
        'where' => 
        array (
        ),
        'as' => 'supuser.profileupdate.pass.dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'supuser.listuser' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Administrator/SuperUser/Dashboard/Users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'supUser',
          3 => 'PreBackHistory',
          4 => 'is_user_verify_email',
        ),
        'uses' => 'App\\Http\\Controllers\\SupUser\\User\\ListUserController@index',
        'controller' => 'App\\Http\\Controllers\\SupUser\\User\\ListUserController@index',
        'namespace' => NULL,
        'prefix' => '/Administrator/SuperUser',
        'where' => 
        array (
        ),
        'as' => 'supuser.listuser',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'supuser.users.team' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Administrator/SuperUser/Dashboard/Users/Team/List',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'supUser',
          3 => 'PreBackHistory',
          4 => 'is_user_verify_email',
        ),
        'uses' => 'App\\Http\\Controllers\\SupUser\\Team\\ListTeamController@index',
        'controller' => 'App\\Http\\Controllers\\SupUser\\Team\\ListTeamController@index',
        'namespace' => NULL,
        'prefix' => '/Administrator/SuperUser',
        'where' => 
        array (
        ),
        'as' => 'supuser.users.team',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'supuser.cata.super' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Administrator/SuperUser/Dashboard/Catagory/SuperCatagory',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'supUser',
          3 => 'PreBackHistory',
          4 => 'is_user_verify_email',
        ),
        'uses' => 'App\\Http\\Controllers\\SupUser\\Catagory\\SupCatagoryController@index',
        'controller' => 'App\\Http\\Controllers\\SupUser\\Catagory\\SupCatagoryController@index',
        'namespace' => NULL,
        'prefix' => '/Administrator/SuperUser',
        'where' => 
        array (
        ),
        'as' => 'supuser.cata.super',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'supuser.cata.super.insert' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Administrator/SuperUser/Dashboard/Catagory/SuperCatagory/Insert',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'supUser',
          3 => 'PreBackHistory',
          4 => 'is_user_verify_email',
        ),
        'uses' => 'App\\Http\\Controllers\\SupUser\\Catagory\\SupCatagoryController@insert',
        'controller' => 'App\\Http\\Controllers\\SupUser\\Catagory\\SupCatagoryController@insert',
        'namespace' => NULL,
        'prefix' => '/Administrator/SuperUser',
        'where' => 
        array (
        ),
        'as' => 'supuser.cata.super.insert',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'supuser.blank' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Administrator/SuperUser/BlankPage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'supUser',
          3 => 'PreBackHistory',
          4 => 'is_user_verify_email',
        ),
        'uses' => 'App\\Http\\Controllers\\SupUser\\SupUserDashController@blank',
        'controller' => 'App\\Http\\Controllers\\SupUser\\SupUserDashController@blank',
        'namespace' => NULL,
        'prefix' => '/Administrator/SuperUser',
        'where' => 
        array (
        ),
        'as' => 'supuser.blank',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'blogusr.dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Administrator/Blogger/Dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'blogUser',
          3 => 'PreBackHistory',
          4 => 'is_user_verify_email',
        ),
        'uses' => 'App\\Http\\Controllers\\Blogger\\BloggerDashController@index',
        'controller' => 'App\\Http\\Controllers\\Blogger\\BloggerDashController@index',
        'namespace' => NULL,
        'prefix' => '/Administrator/Blogger',
        'where' => 
        array (
        ),
        'as' => 'blogusr.dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'blogusr.users' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Administrator/Blogger/Dashboard/Users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'blogUser',
          3 => 'PreBackHistory',
          4 => 'is_user_verify_email',
        ),
        'uses' => 'App\\Http\\Controllers\\Blogger\\AllPartUser\\ListUserController@index',
        'controller' => 'App\\Http\\Controllers\\Blogger\\AllPartUser\\ListUserController@index',
        'namespace' => NULL,
        'prefix' => '/Administrator/Blogger',
        'where' => 
        array (
        ),
        'as' => 'blogusr.users',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'blogusr.profile.dash' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Administrator/Blogger/Dashboard/Profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'blogUser',
          3 => 'PreBackHistory',
          4 => 'is_user_verify_email',
        ),
        'uses' => 'App\\Http\\Controllers\\Blogger\\BloggerDashController@userProfile',
        'controller' => 'App\\Http\\Controllers\\Blogger\\BloggerDashController@userProfile',
        'namespace' => NULL,
        'prefix' => '/Administrator/Blogger',
        'where' => 
        array (
        ),
        'as' => 'blogusr.profile.dash',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'blogusr.profile.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Administrator/Blogger/Dashboard/Profile/Update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'blogUser',
          3 => 'PreBackHistory',
          4 => 'is_user_verify_email',
        ),
        'uses' => 'App\\Http\\Controllers\\Blogger\\BloggerDashController@userProfileUpdate',
        'controller' => 'App\\Http\\Controllers\\Blogger\\BloggerDashController@userProfileUpdate',
        'namespace' => NULL,
        'prefix' => '/Administrator/Blogger',
        'where' => 
        array (
        ),
        'as' => 'blogusr.profile.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'blogusr.profile.update.pass' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Administrator/Blogger/Dashboard/Profile/Update/Pass',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'blogUser',
          3 => 'PreBackHistory',
          4 => 'is_user_verify_email',
        ),
        'uses' => 'App\\Http\\Controllers\\Blogger\\BloggerDashController@userProfileUpdatePass',
        'controller' => 'App\\Http\\Controllers\\Blogger\\BloggerDashController@userProfileUpdatePass',
        'namespace' => NULL,
        'prefix' => '/Administrator/Blogger',
        'where' => 
        array (
        ),
        'as' => 'blogusr.profile.update.pass',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'blogusr.users.allteam' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Administrator/Blogger/Dashboard/Users/Team',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'blogUser',
          3 => 'PreBackHistory',
          4 => 'is_user_verify_email',
        ),
        'uses' => 'App\\Http\\Controllers\\Blogger\\AllPartUser\\TeamUserController@index',
        'controller' => 'App\\Http\\Controllers\\Blogger\\AllPartUser\\TeamUserController@index',
        'namespace' => NULL,
        'prefix' => '/Administrator/Blogger',
        'where' => 
        array (
        ),
        'as' => 'blogusr.users.allteam',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'blogusr.users.allteam.newteam' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Administrator/Blogger/Dashboard/Users/Team/New',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'blogUser',
          3 => 'PreBackHistory',
          4 => 'is_user_verify_email',
        ),
        'uses' => 'App\\Http\\Controllers\\Blogger\\AllPartUser\\TeamUserController@NewTeam',
        'controller' => 'App\\Http\\Controllers\\Blogger\\AllPartUser\\TeamUserController@NewTeam',
        'namespace' => NULL,
        'prefix' => '/Administrator/Blogger',
        'where' => 
        array (
        ),
        'as' => 'blogusr.users.allteam.newteam',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'blogusr.users.allteam.newteam.insert' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Administrator/Blogger/Dashboard/Users/Team/New/TeamInsert',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'blogUser',
          3 => 'PreBackHistory',
          4 => 'is_user_verify_email',
        ),
        'uses' => 'App\\Http\\Controllers\\Blogger\\AllPartUser\\TeamUserController@NewTeamInsert',
        'controller' => 'App\\Http\\Controllers\\Blogger\\AllPartUser\\TeamUserController@NewTeamInsert',
        'namespace' => NULL,
        'prefix' => '/Administrator/Blogger',
        'where' => 
        array (
        ),
        'as' => 'blogusr.users.allteam.newteam.insert',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'blogusr.users.allteam.users' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Administrator/Blogger/Dashboard/Users/Team/List/{nameteam}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'blogUser',
          3 => 'PreBackHistory',
          4 => 'is_user_verify_email',
        ),
        'uses' => 'App\\Http\\Controllers\\Blogger\\AllPartUser\\ListUserController@TeamUserList',
        'controller' => 'App\\Http\\Controllers\\Blogger\\AllPartUser\\ListUserController@TeamUserList',
        'namespace' => NULL,
        'prefix' => '/Administrator/Blogger',
        'where' => 
        array (
        ),
        'as' => 'blogusr.users.allteam.users',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'blogusr.users.allteam.users.add' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Administrator/Blogger/Dashboard/Users/Team/List/AddUser/{name_user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'blogUser',
          3 => 'PreBackHistory',
          4 => 'is_user_verify_email',
        ),
        'uses' => 'App\\Http\\Controllers\\Blogger\\AllPartUser\\ListUserController@TeamAddUser',
        'controller' => 'App\\Http\\Controllers\\Blogger\\AllPartUser\\ListUserController@TeamAddUser',
        'namespace' => NULL,
        'prefix' => '/Administrator/Blogger',
        'where' => 
        array (
        ),
        'as' => 'blogusr.users.allteam.users.add',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'email.verify' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'User/Verify',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\RegisterController@verify',
        'controller' => 'App\\Http\\Controllers\\Auth\\RegisterController@verify',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'email.verify',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'basUser.view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'User/view',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:web',
          2 => 'basUser',
          3 => 'PreBackHistory',
        ),
        'uses' => 'App\\Http\\Controllers\\BasUser\\BasUsrDashController@index',
        'controller' => 'App\\Http\\Controllers\\BasUser\\BasUsrDashController@index',
        'as' => 'basUser.view',
        'namespace' => NULL,
        'prefix' => '/User',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'basUser.dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'User/Dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'basUser',
          3 => 'PreBackHistory',
          4 => 'is_user_verify_email',
        ),
        'uses' => 'App\\Http\\Controllers\\BasUser\\BasUsrDashController@index',
        'controller' => 'App\\Http\\Controllers\\BasUser\\BasUsrDashController@index',
        'as' => 'basUser.dashboard',
        'namespace' => NULL,
        'prefix' => '/User',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'cybsam.dev.optimize' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'CybSamDevelopment/Optimize',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\CybSamDev\\CybDevController@optimize',
        'controller' => 'App\\Http\\Controllers\\CybSamDev\\CybDevController@optimize',
        'namespace' => NULL,
        'prefix' => '/CybSamDevelopment',
        'where' => 
        array (
        ),
        'as' => 'cybsam.dev.optimize',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
