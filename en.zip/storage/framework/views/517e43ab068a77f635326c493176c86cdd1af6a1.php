<!-- ======= Footer ======= -->
<footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>HowTinue</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
      Designed by <a href="#">CybSam</a>
    </div>
  </footer><!-- End Footer -->
<?php /**PATH C:\Users\SHUVO\Desktop\Laravel\en\resources\views/layouts/SupUserInc/SupUserFooter.blade.php ENDPATH**/ ?>