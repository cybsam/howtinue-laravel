<body>
    <!-- Preloader -->
    <div class="preloader d-flex align-items-center justify-content-center">
        <div class="lds-ellipsis">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>
<?php /**PATH C:\Users\SHUVO\Desktop\Laravel\en\resources\views/layouts/FrontEndInc/preload.blade.php ENDPATH**/ ?>