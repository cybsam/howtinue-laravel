<?php $__env->startSection('title', 'Blogger - HowTinue'); ?>
<?php $__env->startSection('BlogUserContent'); ?>

<div class="pagetitle">
    <h1>Blogger Dashboard</h1>
    <nav>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(url('Bolgger/Dashboard')); ?>">Home</a></li>
    </ol>
    </nav>
</div><!-- End Page Title -->




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.BlogUserMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SHUVO\Desktop\Laravel\en\resources\views/BlogUserDash/index.blade.php ENDPATH**/ ?>