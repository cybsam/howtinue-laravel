
<?php $__env->startSection('title', 'Team Users List - HowTinue'); ?>
<?php $__env->startSection('BlogUserContent'); ?>

<div class="pagetitle">
    <h1><?php echo e(Session::get('team_name')); ?> Team Users List</h1>
    <nav>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('blogusr.dashboard')); ?>">Home</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('blogusr.users')); ?>">Users</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('blogusr.users.allteam')); ?>">Team</a></li>
        <li class="breadcrumb-item active">Team Users List</li>
    </ol>
    </nav>
</div>

<div class="section">
    <div class="row">
        <div class="col-md-8 m-auto">
            <a class=" btn btn-outline-info" href="<?php echo e(route('blogusr.users')); ?>">Add User</a>
        </div>
    </div>
</div>

<div class="section">
    <div class="row">
        <div class="col-md-10 m-auto">
            
            <div class="card">
                <div class="card-body">
                  <h5 class="card-title">Users List</h5>
            
                  <table class="table table-hover datatable table-sm">
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Name</th>
                        <th scope="col">Username</th>
                        <th scope="col">Email</th>
                        <th scope="col">Verified</th>
                        <th scope="col">Status</th>
                        <th scope="col">Team</th>
                        <th >Register</th>
                        <th scope="col">Action</th>
                      </tr>
                    </thead>
                    <tbody>
            
                        <?php $__currentLoopData = $teamNameI; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userTeam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      
                        
                        <th scope="row"><a href="#">#<?php echo e($userTeam->id); ?></a></td>
                        <td><?php echo e($userTeam->name); ?></td>
                        <td><a class="" href=""><span>@</span><?php echo e($userTeam->username); ?></a></td>
                        <td><?php echo e(Str::limit($userTeam->email, 6)); ?></td>
                        
            
                        <td><a href="" class="badge rounded-pill bg-<?php echo e($userTeam->block == 0 ? 'success':'danger'); ?>"> <?php if($userTeam->block == 0): ?> <span class="text-white"><i class="bi bi-person-check-fill"></i></span> <?php else: ?> <span class="text-white"><i class="bi bi-person-x-fill"></i></span>  <?php endif; ?></a></td>
                        <td><span class="badge rounded-pill bg-info"><?php echo e($userTeam->teamname); ?></span></td>
                        
                        <td><a class="text-success" href=""><i class="bi bi-pencil-square"></i></a><span>&nbsp;&nbsp;</span><a class="text-danger" href=""><i class="bi bi-trash"></i></a></td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
                    </tbody>
                </table>
                </div>
            </div> 
        </div>
        
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.BlogUserMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SHUVO\Desktop\Laravel\en\resources\views/BlogUserDash/Users/TeamUserList.blade.php ENDPATH**/ ?>