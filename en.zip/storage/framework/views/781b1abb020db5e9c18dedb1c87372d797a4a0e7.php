
<?php $__env->startSection('title', 'Team: Modarator - HowTinue'); ?>
<?php $__env->startSection('BlogUserContent'); ?>

<div class="pagetitle">
    <h1> Team Management</h1>
    <nav>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('blogusr.dashboard')); ?>">Home</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('blogusr.users')); ?>">Users</a></li>
        <li class="breadcrumb-item active">Users Team</li>
    </ol>
    </nav>
</div><!-- End Page Title -->


      <a class=" btn btn-outline-info" href="<?php echo e(route('blogusr.users.allteam.newteam')); ?>">New Team</a>

      <a class=" btn btn-outline-warning" href="#">Modified team</a>

        <a class="btn btn-outline-danger" href="#">Delete team</a>
        <hr>
        <section class="section">
            <div class="row">
                <?php if( Session::get('success') ): ?>
                <div class="alert alert-primary bg-primary text-light border-0 alert-dismissible fade show" role="alert">
                    <?php echo e(Session::get('success')); ?>

                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
                  </div>
                <?php endif; ?>
                <?php $__currentLoopData = $teamInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teamin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
               
              <div class="col-lg-4">
      
                <div class="card">
                  <div class="card-body">
                    <h5 class="card-title"><?php echo e($teamin->teamname); ?></h5>
      
                    <div class="btn-group" role="group" aria-label="Basic example">
                      <?php
                        $teamname = $teamin->teamname
                      ?>
                      <a href="<?php echo e(route('blogusr.users.allteam.users',$teamname)); ?>" class="btn btn-outline-primary ">Users</a>
                      <a href="" class="btn btn-outline-warning ">Check Post</a>
                      <a href="" class="btn btn-outline-primary">Right</a>
                      </div>
      
                  </div>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </div>
        </section>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.BlogUserMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SHUVO\Desktop\Laravel\en\resources\views/BlogUserDash/Users/TeamUser.blade.php ENDPATH**/ ?>