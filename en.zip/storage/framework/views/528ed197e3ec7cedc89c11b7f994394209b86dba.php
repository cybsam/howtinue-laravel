
<?php $__env->startSection('title', 'Team: Modarator - HowTinue'); ?>
<?php $__env->startSection('BlogUserContent'); ?>

<div class="pagetitle">
    <h1>Team Management</h1>
    <nav>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('blogusr.dashboard')); ?>">Home</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('blogusr.users')); ?>">Users</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('blogusr.users.allteam')); ?>">Team</a></li>
        <li class="breadcrumb-item active">New Team</li>
    </ol>
    </nav>
</div><!-- End Page Title -->

<div class="row">
    <div class="col-md-8 m-auto">
        <div class="card">
            <div class="card-body">
              <h5 class="card-title">New Team Information</h5>
              <?php if($errors->all()): ?>
                    <span class="text-danger">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </span>
                <?php endif; ?>
                
              <form class="row g-3" action="<?php echo e(route('blogusr.users.allteam.newteam.insert')); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                <div class="col-md-12">
                  <label for="inputTeamName" class="form-label">Team Name</label>
                  <input type="text" class="form-control <?php $__errorArgs = ['teamname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('teamname')); ?>" name="teamname" placeholder="eg: technology, food, devices etc" id="teamname">
                  
                </div>
                <div class="col-md-6">
                  <label for="inputUserName" class="form-label">Moderator Name</label>
                  <input type="email" class="form-control" name="admin_name" value="<?php echo e(Auth::user()->name); ?>" id="admin_name"  readonly>
                </div>
                <div class="col-md-6">
                  <label for="inputUserEmail" class="form-label">Moderator Email</label>
                  <input type="email" class="form-control" name="admin_email" value="<?php echo e(Auth::user()->email); ?>" id="admin_email" readonly>
                </div>
                <input type="hidden" name="admin_id" id="admin_id" value="<?php echo e(Auth::user()->id); ?>">
                <div class="text-center">
                  <button type="submit" class="btn btn-primary">New Team</button>
                  <button type="reset" class="btn btn-secondary">Reset</button>
                </div>
              </form><!-- End Multi Columns Form -->
        
            </div>
          </div>
    </div>
</div>







<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.BlogUserMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SHUVO\Desktop\Laravel\en\resources\views/BlogUserDash/Users/NewTeam.blade.php ENDPATH**/ ?>