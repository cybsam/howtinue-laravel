
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title><?php echo $__env->yieldContent('FrontTitle'); ?></title>

    <!-- Favicon -->
    <link rel="icon" href="<?php echo e(asset('FrontEnd/img/core-img/favicon.ico')); ?>">

    <!-- Stylesheet -->
    <link rel="stylesheet" href="<?php echo e(asset('FrontEnd/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('FrontEnd/css/cus.css')); ?>">

</head>

<?php echo $__env->make('layouts.FrontEndInc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.FrontEndInc.preload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




       <?php echo $__env->yieldContent('FrontEnd'); ?>

</section>
    <?php echo $__env->make('layouts.FrontEndInc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.FrontEndInc.copywrite', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="<?php echo e(asset('FrontEnd/js/jquery/jquery-2.2.4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('FrontEnd/js/bootstrap/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('FrontEnd/js/bootstrap/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('FrontEnd/js/plugins/plugins.js')); ?>"></script>
    <!-- Active js -->
    <script src="<?php echo e(asset('FrontEnd/js/active.js')); ?>"></script>
</body>
</html>



<?php /**PATH C:\Users\SHUVO\Desktop\Laravel\en\resources\views/layouts/FrontEndMaster.blade.php ENDPATH**/ ?>