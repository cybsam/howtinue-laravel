
<?php $__env->startSection('title', 'Team - HowTinue'); ?>
<?php $__env->startSection('SupUserContent'); ?>

<div class="pagetitle">
    <h1>Team Management</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('supuser.dashboard')); ?>">Home</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('supuser.listuser')); ?>">Users</a></li>
        <li class="breadcrumb-item active">Team</li>
      </ol>
    </nav>
  </div><!-- End Page Title -->

  <section class="section">
    <div class="row">
        
        <?php $__currentLoopData = $listTeam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teamin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
       
      <div class="col-lg-4">

        <div class="card">
          <div class="card-body">
            <h5 class="card-title"><?php echo e($teamin->admin_name); ?>'s &nbsp; => <?php echo e($teamin->teamname); ?> </h5>

            <div class="btn-group" role="group" aria-label="Basic example">
                <a href="" class="btn btn-outline-primary ">Users</a>
                <a href="" class="btn btn-outline-warning ">Information</a>
                <a href="" class="btn btn-outline-secondary">Right</a>
              </div>

          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </div>
</section>

  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.SupUserMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SHUVO\Desktop\Laravel\en\resources\views/SupUserDash/Team/index.blade.php ENDPATH**/ ?>