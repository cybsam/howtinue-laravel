@extends('layouts.SupUserMaster')
@section('title', 'Super Catagory - HowTinue')
@section('SupUserContent')


<div class="pagetitle">
    <h1>Super Catagory</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="{{ route('supuser.dashboard') }}">Home</a></li>
        
        <li class="breadcrumb-item active">Super Catagory</li>
      </ol>
    </nav>
</div>



@endsection