<div class="copywrite-area">
    <div class="container">
        <div class="row align-items-center">
            
            <div class="col-12 col-sm-6">
                <p class="copywrite-text">
&copy; <script>document.write(new Date().getFullYear());</script>  <a href="{{ route('FrontEnd.Index') }}">HowTinue Inc</a> | All Rights Reserved - Designed by <a href="#" target="_blank">CybSam</a>
</p>
            </div>
            <div class="col-12 col-sm-6">
                <nav class="footer-nav">
                    <ul>
                        <li><a href="#">Advertise</a></li>
                        <li><a href="#">About</a></li>
                        <li><a href="#">Contact</a></li>
                        <li><a href="#">Disclaimer</a></li>
                        <li><a href="#">Privacy</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</div>
</footer>